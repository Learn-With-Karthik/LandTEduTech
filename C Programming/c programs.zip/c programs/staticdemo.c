#include<stdio.h>
static char c;
static int i;
static float f;

int main ()
{
	
printf("%d %d %f \n",c,i,f); // the initial default values will be printed.
display();

printf("%d %d %f\n",c,i,f); // the initial default values will be printed.
return 0;
} 


void display()
{
 	f++;
}

