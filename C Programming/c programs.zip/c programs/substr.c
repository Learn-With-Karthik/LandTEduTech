#include<stdio.h>  
#include <string.h>    
int main(){    
  char str[100]="this is c prog compared to java prog";    
  char *sub;    
  sub=strstr(str,“prog");    
  printf("\nSubstring is: %s",sub);    
 return 0;    
}
