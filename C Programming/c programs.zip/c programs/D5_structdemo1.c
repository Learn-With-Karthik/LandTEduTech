#include <stdio.h>
#include <string.h>

struct Student
{
   int studid;
   char studname[50];
   int marks[5];
   int total;
};

int main()
{ 
	struct Student stud1;
	int temp[5]={56,78,88,98,10};
	stud1.studid=1001; 
	strcpy(stud1.studname,"Athaulla");
	stud1.marks[0]=56;
	stud1.marks[1]=56;
	stud1.marks[2]=56;
	stud1.marks[3]=56;
	stud1.marks[4]=56;
	stud1.total=500;
	printf("%d Student %s  scored total of %d %d\n" , stud1.studid,stud1.studname, stud1.marks[0],stud1.total);

	struct Student stud2={1002, "Arun", {56,78,88,98,10}, 567};
    printf("%d Student %s  scored total of %d %d" , stud2.studid,stud2.studname, stud2.marks[0],stud2.total);
}