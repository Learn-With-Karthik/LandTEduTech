#include<stdio.h>
#include<string.h>
struct Subject  
{  
    char sub_name[30];  
    int sub_id;  
    char sub_duration[50];  
    char sub_type[50];  
};
int main()  
{  
    struct Subject sub; // declare the Subject variable  
    struct Subject *ptr; // create a pointer variable (*ptr)   
    ptr = &sub; /* ptr variable pointing to the address of the structure variable sub */  
      
    strcpy (sub.sub_name, "Computer Science");  
    sub.sub_id = 1001;  
    strcpy (sub.sub_duration, "12 Months");  
    strcpy (sub.sub_type, "Multiple Choice Question");  
  
    // print the details of the Subject;  
    printf ("Subject Name: %s\t\n",(*ptr).sub_name);  
    printf ("Subject Id: %d\t\n",(*ptr).sub_id);  
    printf ("Duration of the Subject: %s\t\n",(*ptr).sub_duration);  
    printf ("Type of the Subject: %s\t\n",(*ptr).sub_type);  
    return 0;  
}
