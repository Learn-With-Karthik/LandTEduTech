#include<stdio.h>  
#include <string.h>   
void main ()  
{  
    char s[11] = "ProgrAmming";  
    int i = 0;   
    int count = 0;  
    while(s[i] != NULL)     //while(s<11)
    {  
        if(s[i]=='a' || s[i] == 'e' || s[i] == 'i' || s[i] == 'u' || s[i]== 'o' || s[i]=='A' )  
        {  
            count ++;  
        }  
        i++;  
    } 
    printf("The number of vowels %d",count);  
} 