#include <stdio.h>
int factorial(int i)
{
   if(i <= 1) {
      return 1;
   }
   return i * factorial(i - 1);
}
int  main() 
{
   int n;
   printf("Enter the number\n");
   scanf("%d",&n);
   printf("Factorial is %d\n",factorial(n));
   return 0;
}
