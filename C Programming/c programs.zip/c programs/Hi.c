Hi welcome to C progrmming File Handling Concepts
