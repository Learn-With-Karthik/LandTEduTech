//#include<stdio.h>
//union abc  
//{  
//  int a;  
//  char b;   
//} var;  
//int main()  
//{  
//  var.a = 66;  
//  printf("a = %d\n",var.a);  
//  printf("b = %d",var.b);  
//  return 0;
//} 
//
#include <stdio.h>  
union abc  
{  
    int a;  
    char b;  
};  
int main()  
{  
    union abc *ptr; // pointer variable declaration  
    union abc var;  
    var.a= 90;  
    ptr = &var;  
    printf("The value of a is : %d", ptr->b);  
    return 0;  
} 


//#include<stdio.h>
//union abc
//{  
////int a;  
//char b;  
////float c;  
////double d;  
//};  
//int main()  
//{  
//  printf("Size of union abc is %d", sizeof(union abc));  
//  return 0;  
//}
