//#include <stdio.h>
//const int MAX = 3;
//int main () {
//   int  var[] = {10, 100, 200};
//   int  i, *ptr;
//   /* let us have array address in pointer */
//   ptr = var;
//	
//   for ( i = 0; i < MAX; i++) {
//      printf("Address of var[%d] = %x\n", i, ptr );
//      printf("Value of var[%d] = %d\n", i, *ptr );
//
//      /* move to the next location */
//      ptr++;
//   }
//   return 0;
//}



#include <stdio.h>
int main()
{
    int a[5]={1,2,3,4,5};   //array initialization
    int *p;     //pointer declaration
               /*the ptr points to the first element of the array*/

    p=a; /*We can also type simply ptr==&a[0] */
    
    printf("Printing the array elements using pointer\n");
    for(int i=0;i<5;i++)    //loop for traversing array elements
    {
			printf("Address of a[%d] = %d\n", i, p );
        	printf("%x\n",*p);  //printing array elements
        	p++;    //incrementing to the next element, you can also write p=p+1
    }
    return 0;
}



