#include<stdio.h>
int main()
{
	char gender;
	int dependent;
	printf("Enter the gender\n");
	scanf("%c",&gender);
	printf("Enter number of dependents\n");
	scanf("%d",&dependent);
	if (gender=='M')
	{
		if (dependent==0)
			printf("Male employee will get 10 percent deduction");
		else if(dependent==1)
			printf("Male employee will get 20 percent deduction");
		else
			printf("Male employee will get 30 percent deduction");
	} 
	else if (gender=='F')
	{
		if (dependent==0)
			printf("Female employee will get 15 percent deduction");
		else if(dependent==1)
			printf("Female employee will get 25 percent deduction");
		else
			printf("Female employee will get 35 percent deduction");
	}
	else
		printf("Invalid gender");
	return 0;
}
