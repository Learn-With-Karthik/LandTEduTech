#include <stdio.h>
void sum (int *n);
int main()
{
     int a = 5;
     printf("\n The value of 'a' before the calling function is = %d", a);
     sum(&a);
     printf("\n The value of 'a' after calling the function is = %d", a);
     return 0;
}
void sum (int *n)
{
     *n = *n + 20;
     printf("\n value of 'n' in the called function is = %d", *n);
}
