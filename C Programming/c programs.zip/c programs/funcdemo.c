#include<stdio.h>
	int main()
	{
	  
		int n1,n2,res;   
		printf("enter the first number=");    
		scanf("%d",&n1); 
		   
		printf("enter the second number=");    
		scanf("%d",&n2); 
		greeting();
		res = sum(n1,n2);
		printf("Result is %d  \n", res);    
		display("Bye Please come back\n");
	   	return 0;
}


    int sum(int a, int b)
    {
    	return a+b;
	}
	
	void greeting()
	{
		printf("Welcome Function Demo Program\n");
	}
	
	
	void display(char msg[])
	{
		printf("%s", msg);
		
	}