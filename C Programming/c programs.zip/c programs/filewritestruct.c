#include <stdio.h>
#include <stdlib.h>
 

struct Student {
    int id;
    char fname[20];
    char lname[20];
};
 
int main()
{
    FILE* outfile;
 
    outfile = fopen("student.bin", "wb");
    if (outfile == NULL) {
        fprintf(stderr, "\nError opened file\n");
        exit(1);
    }
 
    struct Student student1 = { 1, "Athaulla", "Ghouse" };
 
    int flag = 0;
 
    flag = fwrite(&student1, sizeof(struct Student), 1,
                  outfile);
    if (flag) {
        printf("Contents of the student structure written successfully");
    }
    else
        printf("Error Writing to File!");
 

    fclose(outfile);
 
    return 0;
}