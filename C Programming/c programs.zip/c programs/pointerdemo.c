#include <stdio.h>

int  main() 
{
   int n,m;
   int *p;
   
   printf("Enter the number\n");
   scanf("%d",&n);
   printf("value is %d\n",n);
   printf("stored in this address %d\n",&n);
   //m=&n;
   p=&n;
   //printf("stored in this address %d\n",m);
   printf("value stored in this address using pointer d %d\n",*p);
   printf("value stored in this address using pointer d %d\n",p);
   printf("value stored in this address using pointer p %p\n",p);
   printf("value stored in this address using pointer o %o\n",p);
   printf("value stored in this address using pointer X %x\n",p);

   printf("stored in this address %d\n",p);
   //m++;
//   p++;
//   //printf("stored in this address after increment %d\n",m);
//   printf("stored in this address after increment using pointer %d\n",p);
//   printf("value stored in this address after increment using pointer %d\n",*p);
//   
   return 0;
}