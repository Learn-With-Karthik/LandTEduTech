#include<stdio.h>  
#include <string.h>   
void main ()  
{  
    char s[11] = "Programming";  
    int i = 0;   
    int count = 0;  
    while(s[i] != NULL)     //while(s<11)
    {  
        if(strlwr(s[i])=='a' || strlwr(s[i]) == 'e' || strlwr(s[i]) == 'i' || strlwr(s[i]) == 'u' || strlwr(s[i]) == 'o')  
        {  
            count ++;  
        }  
        i++;  
    } 
    printf("The number of vowels %d",count);  
} 