#include<stdio.h>  
void main ()  
{  
    char s[30];  
    printf("Enter the string? ");  
    //gets(s); 
	fgets(s, 20, stdin); 
    printf("You entered %s",s);  
} 
