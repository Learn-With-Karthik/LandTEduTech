#include<stdio.h>  
int main(){      
int i=0;    
int marks[5];//declaration and initialization of array    
 //traversal of array    

for(i=0;i<5;i++){      
scanf("%d",&marks[i]);    
}    

int sum=0;

for(i=0;i<5;i++)
{
sum += marks[i];    
}    

printf("Sum value is %d", sum);

return 0;  
} 
