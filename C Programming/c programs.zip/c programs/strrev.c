#include<stdio.h>  
#include <string.h>    
int main(){    
  char str[20];    
  printf("Enter string: ");    
  gets(str);//reads string from console    
  printf("String is: %s",str); 
  int len=strlen(str);
  char rstr[len];
 // rstr= strrev(str);
  printf("\nReverse String is: %s \n",strrev(str));    
  
  if (str == strrev(str))
  
  	printf("Palindrome");

 return 0;   
 
 
  
} 
