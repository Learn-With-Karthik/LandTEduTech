#include<stdio.h>  
#include <string.h>    
int main(){    
  char str1[20],str2[20];    
  printf("Enter 1st string: ");    
  gets(str1);//reads string from console    
  
  if (strcmp(str1,strrev(str1)==0))
  {
  	printf("Palindrome");
  	
  }
  else
  {
  	printf("Not Palindrome");
  }
  return 0;
}