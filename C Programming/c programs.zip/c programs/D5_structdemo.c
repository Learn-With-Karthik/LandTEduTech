struct Student
{
   int studid;
   char studname[30];
   //int marks[5];
   int total;
} stud1;
int main()
{
	printf("Size of the structure is %d",sizeof(stud1));
	return 0;
}
