#include<stdio.h>  
#include <string.h>    
int main(){    
char ch[20]={'c', 'p', 'r', 'o', 'g', 'r', 'a', 'm', 'm', 'i', 'n', 'g', '\0'};    
   printf("Length of string is: %d",strlen(ch));    
 return 0;    
} 
