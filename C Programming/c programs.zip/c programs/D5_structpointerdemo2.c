#include<stdio.h>
struct Employee  
{  
    char name[30];  
    int id;
    char city[40];  
}; 

struct Employee emp1, *ptr1;

int main()  
{  
    ptr1 = &emp1;  
     
    printf ("Enter the name of the Employee\n");  
    scanf ("%s",ptr1->name);  
    printf ("Enter the id\n");  
    scanf ("%d",&ptr1->id);  
    printf ("Enter the city\n");  
    scanf ("%s",&ptr1->city);  
      
    printf ("Display the Details of the Employee using Structure Pointer\n");  
    printf("Name: %s\n", ptr1->name);  
    printf("Id: %d\n", ptr1->id);  
    printf("City: %s\n", ptr1->city);  
    return 0;  
} 
