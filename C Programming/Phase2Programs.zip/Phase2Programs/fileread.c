#include <stdio.h>
#include <string.h>
 
int main()
{
 
    FILE* filePointer;
 
    char dataToBeRead[50];
 
    filePointer = fopen("Hi.txt", "r");
 
    if (filePointer == NULL) {
        printf("Hi.txt file failed to open.");
    }
    else {
 
        printf("The file is now opened.\n");
 
 
       while (fgets(dataToBeRead, 50, filePointer)
               != NULL) {
 
            printf("%s\n", dataToBeRead);
        }
 
        fclose(filePointer);
 
 
        printf("\nData read successfully and file is now closed.");
    }
    return 0;
}