
#include <stdio.h>
#include <string.h>
 
int main()
{
 
    FILE* filePointer;
 
    char dataToBeWritten[50] = "Hi welcome to C progrmming \n File Handling \nConcepts";
 
   filePointer = fopen("Hi.txt", "w");
    //filePointer = fopen("D:\\Hi.c", "w");
 
    if (filePointer == NULL) {
        printf("H.c file failed to open.");
    }
    else {
 
        printf("The file is now opened.\n");
 
        
        if (strlen(dataToBeWritten) > 0) {
 
            fputs(dataToBeWritten, filePointer);
            fputs("\n", filePointer);
        }
 
        fclose(filePointer);
        printf("Data written and file is now closed.");
    }
   
    return 0;
}