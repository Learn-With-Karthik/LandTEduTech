//#include<stdio.h>
//#include<stdlib.h>
//void main(int argc, char *argv[] ) 
//{  
//	printf("Program name is: %s\n", argv[0]);  
//   
//   	if(argc < 2)
//	{  
//    	 printf("No argument passed through command line.\n");  
//   	}  
//   	else
//	{  
//               printf("First argument is: %s\n", argv[1]);  
//               int i=1,sum=0;
//               
//               while(i <= argc)
//               {
//					sum+=atol(argv[i]);
//					i++;               	
//			   }
//	            printf("Sum of commandline Arguments are : %d\n", sum);  		   
//   	}  
//} 

#include<stdio.h>
#include<stdlib.h>
void main(int argc, char *argv[] ) 
{  
	if(argc >= 2)
	{  
		int i=1,sum=0;
		while(i <= argc)
               	{
			sum+=atol(argv[i]);
			i++;               	
		}
	            printf("Sum of commandline Arguments are : %d\n", sum);  		   
   	}  
}