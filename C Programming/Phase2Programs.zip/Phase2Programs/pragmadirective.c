#include <stdio.h>
 
void display();
void show();
 
#pragma startup func1
#pragma exit func2
 
void display() { printf("Inside the function display()\n"); }
 
void show() { printf("Inside the function show()\n"); }
 
int main()
{
    //void display();
    //void show();
    printf("Inside main() Function\n");
 
    return 0;
}